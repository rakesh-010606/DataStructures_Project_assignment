// stack.h
// This header file declares data structures and functions for the Answer History module.
// Answer history is implemented using a stack.
// Each student's attempts are stored in this stack.

#ifndef STACK_H
#define STACK_H

#include <time.h>
#include "queue.h"   // For using Question struct

#define MAX_STUDENT_ID_LEN 20
#define MAX_ATTEMPTS 100
#define MAX_TEXT 100

// Structure to store one attempt of a student
typedef struct Attempt {
    char student_id[MAX_STUDENT_ID_LEN]; // Student identifier
    Question question;                   // The question attempted
    char user_answer[MAX_TEXT];          // User's answer string
    int result;                          // 1=correct, 0=wrong
    int attempt_number;                  // Which attempt number
    time_t timestamp;                    // When the attempt was made
    struct Attempt *next;                // Link to next attempt
} Attempt;

// Stack structure (LIFO)
typedef struct {
    Attempt *top;   // Top of the stack
    int size;       // Current size of stack
} AnswerStack;

// Function declarations
void initStack(AnswerStack *s);                           // Initialize stack
int isEmptyStack(AnswerStack *s);                         // Check empty
int getSize(AnswerStack *s);                              // Get total size
int getStudentAttempts(AnswerStack *s, const char *id);   // Attempts count
int push(AnswerStack *s, const char *id, Question q,const char *ans, int result); // Push attempt
Attempt* popStudent(AnswerStack *s, const char *id);      // Remove last attempt
Attempt* peekStudent(AnswerStack *s, const char *id);     // View last attempt
void displayRecentStudent(AnswerStack *s, const char *id, int n); // Show attempts
void clearStudentAttempts(AnswerStack *s, const char *id);        // Remove all attempts
void freeStack(AnswerStack *s);                          // Free memory

#endif
