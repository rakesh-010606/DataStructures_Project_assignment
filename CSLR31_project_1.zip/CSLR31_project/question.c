// question.c
// Implementation of math helpers and question generators.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "question.h"

// Math helpers
int hcf(int a, int b)
 {
     return b==0?a:hcf(b,a%b);
 }

int lcm(int a, int b)
 {
     return (a*b)/hcf(a,b);
 }

// Generate Fill in the blank
Question generateFIB(int topic) {
    Question q;
    q.qType=0;
    int a=1+rand()%50, b=1+rand()%50;
    int format=rand()%3;
    switch(topic) {
        case 0: // Addition
            if(format == 0)
                sprintf(q.text, "%d + ? = %d", a, a+b);
            else if(format == 1)
                sprintf(q.text, "? + %d = %d", b, a+b);
            else
                sprintf(q.text, "%d + %d = ?", a, b);
            q.answer = a+b - ((format==0) ? a : (format==1 ? b : 0));
            break;

        case 1: // Subtraction
            if(format == 0)
                sprintf(q.text, "%d - ? = %d", a+b, a);
            else if(format == 1)
                sprintf(q.text, "? - %d = %d", a+b, b);
            else
                sprintf(q.text, "%d - %d = ?", a+b, a);
            q.answer = (format==0) ? b : (format==1 ? a : b);
            break;

        case 2: // Multiplication
            if(format == 0)
                sprintf(q.text, "%d * ? = %d", a, a*b);
            else if(format == 1)
                sprintf(q.text, "? * %d = %d", b, a*b);
            else
                sprintf(q.text, "%d * %d = ?", a, b);
            q.answer = (format==0) ? b : (format==1 ? a : a*b);
            break;

        case 3: // Division
            if(b == 0) b = 1;
            if(format == 0)
                sprintf(q.text, "? / %d = %d", b, a);
            else if(format == 1)
                sprintf(q.text, "%d / ? = %d", a*b, a);
            else
                sprintf(q.text, "%d / %d = ?", a*b, b);
            q.answer = (format==0) ? a*b : (format==1 ? b : a);
            break;
        case 4: sprintf(q.text, "LCM of %d and %d = ?", a,b);
                q.answer=lcm(a,b);
                break;
        case 5: sprintf(q.text, "HCF of %d and %d = ?", a,b);
                q.answer=hcf(a,b);
                break;
    }
    q.attempted = 0;

    return q;
}

// Generate Multiple choice question
Question generateMCQ(int topic) {
    Question q;
    q.qType = 1;
    int a = 1 + rand() % 20;
    int b = 1 + rand() % 20;
    int correctOption; // stores the actual correct value
    int format = rand() % 3; // different formats for variety

    switch(topic) {
        case 0: // Addition
            if(format == 0) {
                sprintf(q.text, "%d + ? = %d", a, a+b);
                correctOption = b;
            } else if(format == 1) {
                sprintf(q.text, "? + %d = %d", b, a+b);
                correctOption = a;
            } else {
                sprintf(q.text, "%d + %d = ?", a, b);
                correctOption = a + b;
            }
            break;

        case 1: // Subtraction
            if(format == 0) {
                sprintf(q.text, "%d - ? = %d", a+b, a);
                correctOption = b;
            } else if(format == 1) {
                sprintf(q.text, "? - %d = %d", a+b, b);
                correctOption = a;
            } else {
                sprintf(q.text, "%d - %d = ?", a+b, a);
                correctOption = b;
            }
            break;

        case 2: // Multiplication
            if(format == 0) {
                sprintf(q.text, "%d * ? = %d", a, a*b);
                correctOption = b;
            } else if(format == 1) {
                sprintf(q.text, "? * %d = %d", b, a*b);
                correctOption = a;
            } else {
                sprintf(q.text, "%d * %d = ?", a, b);
                correctOption = a * b;
            }
            break;

        case 3: // Division
            if(b == 0) b = 1;
            if(format == 0) {
                sprintf(q.text, "? / %d = %d", b, a);
                correctOption = a * b;
            } else if(format == 1) {
                sprintf(q.text, "%d / ? = %d", a*b, a);
                correctOption = b;
            } else {
                sprintf(q.text, "%d / %d = ?", a*b, b);
                correctOption = a;
            }
            break;

        case 4: // LCM
            if(format == 0) {
                sprintf(q.text, "LCM of ? and %d = %d", b, lcm(a,b));
                correctOption = a;
            } else if(format == 1) {
                sprintf(q.text, "LCM of %d and ? = %d", b, lcm(a,b));
                correctOption = a;
            } else {
                sprintf(q.text, "LCM of %d and %d = ?", a,b);
                correctOption = lcm(a,b);
            }
            break;

        case 5: // HCF
            if(format == 0) {
                sprintf(q.text, "HCF of ? and %d = %d", b, hcf(a,b));
                correctOption = a;
            } else if(format == 1) {
                sprintf(q.text, "HCF of %d and ? = %d", b, hcf(a,b));
                correctOption = a;
            } else {
                sprintf(q.text, "HCF of %d and %d = ?", a,b);
                correctOption = hcf(a,b);
            }
            break;
    }

    // Randomly assign correct option index 1-4
    q.answer = 1 + rand() % 4;

    // Fill options array
    for(int i = 0; i < 4; i++) {
        if(i+1 == q.answer) {
            sprintf(q.options[i], "%d", correctOption); // correct answer
        } else {
            int opt;
            do {
                opt = correctOption + (rand() % 5 + 1); // variation 1-5
            } while(opt == correctOption); // avoid duplicate
            sprintf(q.options[i], "%d", opt);
        }
    }

    q.attempted = 0;
    return q;
}


// question generator (decides FIB/MCQ/Mixed)
Question generateQuestion(int topic, int typeChoice){
    if(typeChoice==0)
        return generateFIB(topic);
    if(typeChoice==1)
        return generateMCQ(topic);
    if(typeChoice==2)
        return (rand()%2==0)?generateFIB(topic):generateMCQ(topic);
    return generateFIB(topic);
}
