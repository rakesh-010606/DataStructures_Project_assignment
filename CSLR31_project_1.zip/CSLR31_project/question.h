// question.h
// Header file for math question generation.
// Provides declarations for generating Fill-in-the-Blank (FIB)
// and Multiple-Choice (MCQ) questions across topics.

#ifndef QUESTION_H
#define QUESTION_H
#include "queue.h"

#define MAX_TEXT 100
#define MAX_OPTIONS 4


// Function declarations
int hcf(int a, int b);
int lcm(int a, int b);

Question generateFIB(int topic);  // fill in the blank
Question generateMCQ(int topic);  // multiple choice question
Question generateQuestion(int topic, int typeChoice);

#endif

