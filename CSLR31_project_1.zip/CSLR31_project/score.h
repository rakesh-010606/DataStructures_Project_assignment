// score.h
// Header file for tracking question scores in a linked list.

#ifndef SCORE_H
#define SCORE_H

#define MAX_TEXT 100

// ScoreNode structure to store results of each question
typedef struct ScoreNode {
    char question[MAX_TEXT];  // The question text
    int isCorrect;            // 1 = correct, 0 = wrong, -1 = skipped
    int score;                // Score for the question (1 or 0)
    struct ScoreNode *next;   // Pointer to next record

} ScoreNode;

// Global head pointer for score linked list
extern ScoreNode *scoreHead;

// Function declarations
void insertRecord(char *q, int isCorrect);
void displayScore();
void clearScore();

#endif

