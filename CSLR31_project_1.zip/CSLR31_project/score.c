// score.c
// Implementation of score tracking using a linked list.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "score.h"

// Global head pointer (start of linked list)
ScoreNode *scoreHead = NULL;

/*
 * insertRecord - Adds a new score entry at the end of the list.
 * @q: Question text
 * @isCorrect: 1 = correct, 0 = wrong, -1 = skipped
 */
void insertRecord(char *q, int isCorrect) {
    // Allocate memory for new record
    ScoreNode *newNode = (ScoreNode*)malloc(sizeof(ScoreNode));
    if (!newNode) {
        printf("Memory allocation failed for score record.\n");
        return;
    }

    // Initialize fields
    strcpy(newNode->question, q);
    newNode->isCorrect = isCorrect;
    newNode->score = (isCorrect == 1) ? 1 : 0;  // Only correct answers give +1
    newNode->next = NULL;

    // Insert into linked list
    if (!scoreHead) {
        // First node
        scoreHead = newNode;
    } else {
        // Traverse to end
        ScoreNode *curr = scoreHead;
        while (curr->next) {
            curr = curr->next;
        }
        curr->next = newNode;
    }
}

/*
 * displayScore - Prints the score summary.
 * Colors:
 *   Green = correct
 *   Red   = wrong
 *   Yellow= skipped
 */
void displayScore() {
    printf("\n--- Score Summary ---\n");

    if (!scoreHead) {
        printf("No records yet.\n");
        return;
    }

    ScoreNode *curr = scoreHead;
    int total = 0;

    while (curr) {
        // Set terminal color based on correctness
        if (curr->isCorrect == 1)
            {
                printf("\033[0;32m");// Green
                total++;
            }
        else if (curr->isCorrect == 0)
            printf("\033[0;31m"); // Red
        else
            printf("\033[0;33m"); // Yellow

        // Print question and result
       printf("Q: %s | %s\n", curr->question, curr->isCorrect == 1 ? "Correct" :
              (curr->isCorrect == 0 ? "Wrong" : "Not Attempted"));


        // Reset terminal color
        printf("\033[0m");

        curr = curr->next;
    }

    printf("Total Score: %d\n", total);
    printf("----------------------\n");
}


// clearScore - Frees all allocated memory for score records.

void clearScore() {
    while (scoreHead) {
        ScoreNode *temp = scoreHead;
        scoreHead = scoreHead->next;
        free(temp);
    }
}

