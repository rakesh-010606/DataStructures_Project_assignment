// queue.h
// This header file declares the data structures and functions for the Queue module (FIFO).
// It will be included by main.c or other modules


#ifndef QUEUE_H
#define QUEUE_H

#define MAX_TEXT 100
#define MAX_OPTIONS 4

// Structure to represent a math question
typedef struct question{
    char text[MAX_TEXT];         // Question text
    int qType;                   // 0: Fill-in-Blank, 1: MCQ
    int answer;                  // Correct answer (or index for MCQ)
    char options[MAX_OPTIONS][MAX_TEXT]; // Options for MCQ
    int attempted;               // 1 if attempted, 0 if skipped
} Question;

// Node structure for linked list implementation of Queue
typedef struct Node {
    Question q;           // Question stored in this node
    struct Node *next;    // Pointer to next node
} Node;

// Queue structure with front and rear pointers
typedef struct {
    Node *front;          // Points to first node in Queue
    Node *rear;           // Points to last node in Queue
} Queue;

// Function declarations
void initQueue(Queue *q);              // Initialize queue
int isEmpty(Queue *q);                 // Check if queue is empty
void enqueue(Queue *q, Question qn);   // Insert a question at the end
Question dequeue(Queue *q);            // Remove and return front question
Question skipQuestion(Queue *q);       // Mark a question as skipped

#endif

