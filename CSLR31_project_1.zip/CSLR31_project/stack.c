// stack.c
// Implementation of Answer History stack.
// Each student's attempts are stored in a
// stack (LIFO) to easily track most recent attempts.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stack.h"

// Initialize stack
void initStack(AnswerStack *s) {
    s->top = NULL;
    s->size = 0;
}

// Check if stack is empty
int isEmptyStack(AnswerStack *s) {
    return s->top == NULL;
}

// Return total number of attempts in stack
int getSize(AnswerStack *s) {
    return s->size;
}

// Count number of attempts for a specific student
int getStudentAttempts(AnswerStack *s, const char *id) {
    int count = 0;
    Attempt *current = s->top;
    while (current != NULL) {
        if (strcmp(current->student_id, id) == 0) {
            count++;
        }
        current = current->next;
    }
    return count;
}

// Push a new attempt onto the stack
int push(AnswerStack *s, const char *student_id, Question question, const char *user_answer, int result) {
    if (s->size >= MAX_ATTEMPTS) {
        printf("Error: Stack is full (max %d attempts).\n", MAX_ATTEMPTS);
        return 0;
    }
    if (!student_id || !user_answer || strlen(student_id) == 0 || strlen(user_answer) == 0) {
        printf("Error: Invalid student ID or answer.\n");
        return 0;
    }

    Attempt *newAttempt = (Attempt *)malloc(sizeof(Attempt));
    if (newAttempt == NULL) {
        printf("Error: Memory allocation failed!\n");
        return 0;
    }

    strncpy(newAttempt->student_id, student_id, MAX_STUDENT_ID_LEN - 1);
    newAttempt->student_id[MAX_STUDENT_ID_LEN - 1] = '\0';
    newAttempt->question = question; // Copy Question struct
    strncpy(newAttempt->user_answer, user_answer, MAX_TEXT - 1);
    newAttempt->user_answer[MAX_TEXT - 1] = '\0';
    newAttempt->result = result;
    newAttempt->attempt_number = getStudentAttempts(s, student_id) + 1;
    newAttempt->timestamp = time(NULL);
    newAttempt->next = s->top;
    s->top = newAttempt;
    s->size++;
    return 1;
}

// Pop the most recent attempt for a specific student
Attempt* popStudent(AnswerStack *s, const char *student_id) {
    if (isEmptyStack(s)) {
        printf("Error: Stack is empty, cannot pop!\n");
        return NULL;
    }

    Attempt *current = s->top;
    Attempt *prev = NULL;
    while (current != NULL && strcmp(current->student_id, student_id) != 0) {
        prev = current;
        current = current->next;
    }

    if (current == NULL) {
        printf("Error: No attempts found for student %s!\n", student_id);
        return NULL;
    }

    if (prev == NULL) {
        s->top = current->next;
    } else {
        prev->next = current->next;
    }
    s->size--;
    return current; // Caller must free
}


// Peek at the most recent attempt for a specific student
Attempt* peekStudent(AnswerStack *s, const char *student_id) {
    if (isEmptyStack(s)) {
        printf("Error: Stack is empty, cannot peek!\n");
        return NULL;
    }

    Attempt *current = s->top;
    while (current != NULL && strcmp(current->student_id, student_id) != 0) {
        current = current->next;
    }

    if (current == NULL) {
        printf("Error: No attempts found for student %s!\n", student_id);
        return NULL;
    }
    return current;
}


// Display the last N attempts for a specific student
void displayRecentStudent(AnswerStack *s, const char *student_id, int n) {
    if (isEmptyStack(s)) {
        printf("No attempts to display for student %s.\n", student_id);
        return;
    }
    if (n <= 0) {
        printf("Error: Invalid number of attempts to display.\n");
        return;
    }

    printf("\nRecent Attempts for %s (up to %d):\n", student_id, n);
    Attempt *current = s->top;
    int count = 0;
    while (current != NULL && count < n) {
        if (strcmp(current->student_id, student_id) == 0) {
            char *time_str = ctime(&current->timestamp);
            time_str[strcspn(time_str, "\n")] = '\0';
            printf("Attempt %d [%s]: Question: %s, Answer: %s, %s\n",
                   current->attempt_number, time_str,
                   current->question.text, current->user_answer,
                   current->result ? "Correct" : "Wrong");
            if (current->question.qType == 1) {
                printf("Options: ");
                for (int i = 0; i < MAX_OPTIONS; i++) {
                    printf("%d) %s ", i + 1, current->question.options[i]);
                }
                printf("\n");
            }
            count++;
        }
        current = current->next;
        printf("\n");
    }
    if (count == 0) {
        printf("No attempts found for student %s.\n", student_id);
    }
}


// Clear all attempts for a specific student
void clearStudentAttempts(AnswerStack *s, const char *student_id) {
    Attempt *current = s->top;
    Attempt *prev = NULL;
    int removed = 0;

    while (current != NULL) {
        if (strcmp(current->student_id, student_id) == 0) {
            Attempt *temp = current;
            if (prev == NULL) {
                s->top = current->next;
            } else {
                prev->next = current->next;
            }
            current = current->next;
            free(temp);
            s->size--;
            removed++;
        } else {
            prev = current;
            current = current->next;
        }
    }
    if (removed == 0) {
        printf("No attempts found for student %s to clear.\n", student_id);
    } else {
        printf("Cleared %d attempts for student %s.\n", removed, student_id);
    }
}
// Free all stack memory
void freeStack(AnswerStack *s) {
    while (!isEmptyStack(s)) {
        Attempt *temp = s->top;
        s->top = temp->next;
        free(temp);
        s->size--;
    }
}

