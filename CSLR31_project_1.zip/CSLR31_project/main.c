// Main Function //

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Project headers
#include "queue.h"
#include "stack.h"
#include "question.h"
#include "score.h"

#define MAX_TEXT 100
#define MAX_TOPICS 6
#define MAX_OPTIONS 4

int main() {
   srand(time(0));   // Seed random numbers for question generation

   // Initialize the question queue (Member 1)
   Queue q;
   initQueue(&q);

   // Initialize the answer stack (Member 2)
   AnswerStack stack;
   initStack(&stack);

   // Initialize the score linked list (Member 3)
   clearScore();

   //                 Topic Selection
   int selectedTopics[MAX_TOPICS], numTopics = 0;
   printf("Select topics (0:Add,1:Sub,2:Mul,3:Div,4:LCM,5:HCF) end with -1 (with spaces in between): ");
   int t;
   while (scanf("%d", &t) == 1 && t != -1) {
     if (t >= 0 && t < MAX_TOPICS)
       selectedTopics[numTopics++] = t;
   }
   if (numTopics == 0) {
     printf("No valid topics selected. Exiting.\n");
     return 0;
   }

   //              Question Count & Type
   int numQuestions;
   printf("Enter number of questions: ");
   scanf("%d", &numQuestions);

   int typeChoice;
   printf("Select type: 0:FIB 1:MCQ 2:Mixed (press 0,1 or 2): ");
   scanf("%d", &typeChoice);
   if(typeChoice>2)
   typeChoice=2;

   printf("\n\n");
   //              Question Generation
   for (int i = 0; i < numQuestions; i++) {
     int topic = selectedTopics[rand() % numTopics];
     enqueue(&q, generateQuestion(topic, typeChoice));
   }

   char studentID[MAX_STUDENT_ID_LEN] = "student01";

   //            instructions to attempt quiz
   printf("Instruction:\n\n");
   printf("1.Each question has time limit of 10 sec, if u don't answer the question, it will be marked as not attempted\n");
   printf("2.If you answer value greater than 4 for mcqs it will be considered as wrong answer\n");
   printf("3.If you skip the question , i will be considered as wrong answer\n");
   printf("\n\n");
   printf("                       Best of Luck             \n\n");

   //              Quiz Loop
   for (int i = 0; i < numQuestions; i++) {
     Question cur = dequeue(&q);   // Fetch next question
     printf("\nQ%d: %s\n", i + 1, cur.text);

     // If MCQ, print options
     if (cur.qType == 1) {
       for (int j = 0; j < 4; j++)
         printf("%d) %s  ", j + 1, cur.options[j]);
       printf("\n");
     }

     // Track time for answering
     time_t start, end;
     start = time(NULL);

     char choice[10];
     printf("Enter answer or 's' to skip: ");
     scanf("%s", choice);

     end = time(NULL);
     double qTime = difftime(end, start);

     int result = 0;
     char userAnsStr[MAX_TEXT];

     //            Answer Evaluation

     if (qTime > 10) {   // Time exceeded
       printf(" Time exceeded. Marked as skipped.\n");
       strcpy(userAnsStr, "Skipped");
       cur.attempted = 0;
     } else if (choice[0] == 's' || choice[0] == 'S') {  // Skipped
       printf("Question skipped.\n");
       strcpy(userAnsStr, "Skipped");
       cur.attempted = 0;
     } else {
       cur.attempted = 1;
       strcpy(userAnsStr, choice);

       // Checking correctness (FIB or MCQ)
       if (cur.qType == 0) {
         int ans = atoi(choice);
         result = (ans == cur.answer);
       } else {
         int ans = choice[0] - '0';
         result = (ans == cur.answer);
       }
     }

     // Store attempt in stack
     push(&stack, studentID, cur, userAnsStr, result);

     // Store result in score linked list
     int isCorrect = (strcmp(userAnsStr, "Skipped") == 0) ? -1 : result;
     insertRecord(cur.text, isCorrect);
   }

   //            Final Summary
   printf("\n         Summary for %s \n", "student01");

   // Showing attempt history from stack
   displayRecentStudent(&stack, "student01", numQuestions);

   // Showing total score summary
   displayScore();

   //          Cleanup
   freeStack(&stack);   // Free stack memory
   clearScore();        // Free score list memory
   return 0;
}

