// queue.c
// This file defines the functions declared in queue.h.
// The Queue is implemented using a linked list.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "queue.h"

// Initialize queue (set front and rear NULL)
void initQueue(Queue *q) {
    q->front = q->rear = NULL;
}

// Check if queue is empty
int isEmpty(Queue *q) {
    return q->front == NULL;
}

// Insert a new question at the rear of the queue
void enqueue(Queue *q, Question qn) {
    Node *newNode = (Node*)malloc(sizeof(Node));
    newNode->q = qn;
    newNode->next = NULL;

    if (!isEmpty(q)) {
        q->rear->next = newNode; // link from old rear to new node
    }
    q->rear = newNode;           // move rear pointer to new node

    if (isEmpty(q)) {
        q->front = newNode;      // if queue was empty, set front too
    }
}

// Remove and return the front question
Question dequeue(Queue *q) {
    Question dummy = {"No Question", 0, -1, {""}, 0, -1};

    if (isEmpty(q))
        return dummy;  // return dummy if empty

    Node *temp = q->front;         // take the front node
    Question qn = temp->q;         // extract the question
    q->front = temp->next;         // move front to next node

    if (!q->front)
        q->rear = NULL; // if queue is now empty, clear rear too

    free(temp);                    // free memory of removed node
    return qn;
}


